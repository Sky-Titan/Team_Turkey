package org.techtown.turkey_android;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class board_subject_write extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board_subject_write);
    }
}
