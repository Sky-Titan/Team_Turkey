package org.techtown.turkey_android;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

public class board_subject_read extends AppCompatActivity {
    String myJSON;
    JSONArray posts = null;
    String password2check;
    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "id";
    private static final String TAG_NUMBER = "number";
    private static final String TAG_TITLE = "title";
    private static final String TAG_CONTENT = "content";
    private static final String TAG_PASSWORD = "password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board_subject_read);
        TextView bsr_title = (TextView)findViewById(R.id.bsr_title);
        TextView bsr_content = (TextView)findViewById(R.id.bsr_content);
    }

    public void bsr_close(View view)
    {
        finish();
    }
    public void bsr_del(View view)
    {
        EditText scr_password = (EditText)findViewById(R.id.bsr_password);


        if(scr_password.getText().toString()==password2check) {
            Toast.makeText(getApplicationContext(), "삭제되었습니다.", Toast.LENGTH_SHORT).show();
            finish();
            //sql문을 통한 삭제코드 추가할것
        }
        else
        {
            Toast.makeText(getApplicationContext(), "비밀번호를 확인하세요.", Toast.LENGTH_SHORT).show();
        }

    }

}
